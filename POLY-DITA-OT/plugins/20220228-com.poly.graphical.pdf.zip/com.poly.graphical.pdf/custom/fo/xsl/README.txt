About fo/Customization/fo/xsl
=============================

This folder houses custom configuration files that override the
standard ones in fo/cfg/fo/xsl. 

Idiom has provided template files that you can start with throughout
this directory structure.  These files end in the suffix ".orig" (for
example, "catalog.xml.orig").  To enable these files, make a copy of
them and remove the ".orig" suffix.  For example, copy
"custom.xsl.orig" to "custom.xsl".  You can then make modifications
to the copy.

The files in this directory will override the out-of-the-box settings.
See the OpenTopic Customization Guide for more information.
